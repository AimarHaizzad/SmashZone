@extends('layouts.app')

@section('content')
<!-- Enhanced Hero Section -->
<div class="relative mb-12">
    <div class="absolute inset-0 bg-gradient-to-r from-blue-900/90 to-green-900/90 rounded-3xl"></div>
    <img src="/images/badminton-hero.jpg" alt="Badminton Hero" class="w-full h-64 object-cover rounded-3xl shadow-2xl">
    <div class="absolute inset-0 flex flex-col justify-center items-center text-center px-4">
        <div class="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20">
            <h1 class="text-5xl font-extrabold text-white drop-shadow-lg mb-4">Book Your Court</h1>
            <p class="text-xl text-blue-100 font-medium drop-shadow mb-6">Real-time availability • Instant booking • Professional courts</p>
            <div class="flex items-center justify-center gap-6 text-white/90">
                <div class="flex items-center gap-2">
                    <div class="w-3 h-3 bg-green-400 rounded-full"></div>
                    <span class="text-sm font-medium">Available</span>
                </div>
                <div class="flex items-center gap-2">
                    <div class="w-3 h-3 bg-red-400 rounded-full"></div>
                    <span class="text-sm font-medium">Booked</span>
                </div>
                <div class="flex items-center gap-2">
                    <div class="w-3 h-3 bg-blue-400 rounded-full"></div>
                    <span class="text-sm font-medium">My Booking</span>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="max-w-7xl mx-auto py-8 px-4">
    <!-- Enhanced Date Navigation -->
    <div class="bg-white rounded-2xl shadow-lg p-6 mb-8 border border-gray-100">
        <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div class="flex items-center gap-3">
                <button onclick="changeDate(-1)" class="p-3 rounded-xl hover:bg-blue-50 transition-colors border border-gray-200"
                        title="Previous day"
                        aria-label="Go to previous day">
                    <svg class="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7" />
                    </svg>
                    <span class="sr-only">Previous day</span>
                </button>
                <form method="GET" action="" class="flex items-center gap-3">
                    <div class="relative">
                        <input id="date-input" type="date" name="date" value="{{ $selectedDate }}" 
                               class="border-2 border-blue-200 rounded-xl px-4 py-3 shadow-sm focus:ring-2 focus:ring-blue-300 text-lg font-semibold bg-white" 
                               onchange="this.form.submit()"
                               title="Select booking date"
                               aria-label="Select booking date">
                        <div class="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none">
                            <svg class="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                        </div>
                    </div>
                    <span class="text-blue-700 font-bold text-xl">{{ \Carbon\Carbon::parse($selectedDate)->format('j F Y') }}</span>
                    <button type="button" onclick="setToday()" 
                            class="px-4 py-2 bg-blue-50 text-blue-700 rounded-xl border border-blue-200 hover:bg-blue-100 transition font-medium"
                            title="Go to today"
                            aria-label="Go to today's date">
                        Today
                    </button>
                </form>
                <button onclick="changeDate(1)" class="p-3 rounded-xl hover:bg-blue-50 transition-colors border border-gray-200"
                        title="Next day"
                        aria-label="Go to next day">
                    <svg class="h-5 w-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                    <span class="sr-only">Next day</span>
                </button>
            </div>

        </div>
    </div>



    <!-- Enhanced Booking Grid -->
    <div class="bg-white rounded-3xl shadow-xl border border-gray-100 overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full">
                <thead class="sticky top-0 z-20">
                    <tr class="bg-gradient-to-r from-blue-50 to-green-50">
                        <th class="px-6 py-4 border-b border-gray-200 text-center text-blue-700 text-lg font-bold w-32 bg-white"></th>
                        @foreach($courts as $court)
                            <th class="px-6 py-4 border-b border-gray-200 text-center text-blue-700 text-lg font-bold whitespace-nowrap shadow-sm" data-court-id="{{ $court->id }}">
                                <div class="flex flex-col items-center">
                                    <span class="font-bold">{{ $court->name }}</span>
                                    <span class="text-sm font-normal text-gray-600">Court {{ $loop->iteration }}</span>
                                </div>
                            </th>
                        @endforeach
                    </tr>
                </thead>
                <tbody>
                    @foreach($timeSlots as $slotIdx => $slot)
                        @php
                            // Check if any court in this time slot is booked by current user or other users
                            $hasMyBooking = false;
                            $hasOtherBooking = false;
                            foreach($courts as $court) {
                                $booking = $bookings->first(function($b) use ($court, $slot) {
                                    // Convert slot to H:i:s format for comparison
                                    $slotTime = $slot . ':00';
                                    return $b->court_id == $court->id && $b->start_time == $slotTime;
                                });
                                if ($booking) {
                                    if ($booking->user_id == auth()->id()) {
                                        $hasMyBooking = true;
                                    } else {
                                        $hasOtherBooking = true;
                                    }
                                }
                            }
                            $rowClass = $hasMyBooking ? 'bg-blue-50 hover:bg-blue-100' : ($hasOtherBooking ? 'bg-red-50 hover:bg-red-100' : 'hover:bg-gray-50');
                        @endphp
                    <tr class="{{ $rowClass }} transition-colors">
                        <td class="px-4 py-4 border-b border-gray-100 text-right font-bold {{ $hasMyBooking ? 'text-blue-700 bg-blue-100' : ($hasOtherBooking ? 'text-red-700 bg-red-100' : 'text-blue-700 bg-blue-50') }} sticky left-0 z-10 text-lg">
                            {{ \Carbon\Carbon::createFromFormat('H:i', $slot)->format('g:i A') }}
                        </td>
                        @foreach($courts as $court)
                            @php
                                $booking = $bookings->first(function($b) use ($court, $slot) {
                                    // Convert slot to H:i:s format for comparison
                                    $slotTime = $slot . ':00';
                                    return $b->court_id == $court->id && $b->start_time == $slotTime;
                                });
                                $isMine = $booking && $booking->user_id == auth()->id();
                                $isBooked = $booking && !$isMine;
                                $isStart = $booking && $booking->start_time == $slot . ':00';
                                $isEnd = $booking && $booking->end_time == $slot . ':00';
                                
                                // Check if user has a booking that starts at this exact time slot
                                $hasMyBookingInCourt = $bookings->contains(function($b) use ($court, $slot) {
                                    // Convert slot to H:i:s format for comparison
                                    $slotTime = $slot . ':00';
                                    return $b->court_id == $court->id && 
                                           $b->user_id == auth()->id() && 
                                           $b->start_time == $slotTime;
                                });
                                
                                // Alternative check - maybe the time format is different
                                if (!$hasMyBookingInCourt) {
                                    $hasMyBookingInCourt = $bookings->contains(function($b) use ($court, $slot) {
                                        $slotTime = \Carbon\Carbon::createFromFormat('H:i', $slot);
                                        $startTime = \Carbon\Carbon::createFromFormat('H:i:s', $b->start_time);
                                        
                                        return $b->court_id == $court->id && 
                                               $b->user_id == auth()->id() && 
                                               $slotTime->format('H:i:s') == $startTime->format('H:i:s');
                                    });
                                }
                                

                                
                                // If we found a booking, use it
                                if ($hasMyBookingInCourt) {
                                    $booking = $bookings->first(function($b) use ($court, $slot) {
                                        $slotTime = $slot . ':00';
                                        return $b->court_id == $court->id && 
                                               $b->user_id == auth()->id() && 
                                               $b->start_time == $slotTime;
                                    });
                                    
                                    // If the first check didn't find it, try the Carbon time check
                                    if (!$booking) {
                                        $booking = $bookings->first(function($b) use ($court, $slot) {
                                            $slotTime = \Carbon\Carbon::createFromFormat('H:i', $slot);
                                            $startTime = \Carbon\Carbon::createFromFormat('H:i:s', $b->start_time);
                                            
                                            return $b->court_id == $court->id && 
                                                   $b->user_id == auth()->id() && 
                                                   $slotTime->format('H:i:s') == $startTime->format('H:i:s');
                                        });
                                    }
                                }
                                
                                $borderClass = '';
                                if ($isStart) {
                                    $borderClass .= $isMine ? ' border-l-4 border-blue-500' : ' border-l-4 border-red-500';
                                }
                                if ($isEnd) {
                                    $borderClass .= $isMine ? ' border-r-4 border-blue-500' : ' border-r-4 border-red-500';
                                }
                                $bgClass = '';
                                if ($booking) {
                                    $bgClass = $isMine ? ' bg-blue-100 text-blue-700 border-blue-300' : ' bg-red-100 text-red-700 border-red-300';
                                }
                            @endphp
                            <td class="px-3 py-4 border-b border-gray-100 text-center{{ $borderClass }}{{ $bgClass }}" data-court="{{ $court->id }}" data-time="{{ $slot }}">
                                @if($hasMyBookingInCourt && $booking)
                                    @php
                                        $startTime = \Carbon\Carbon::createFromFormat('H:i:s', $booking->start_time);
                                        $endTime = \Carbon\Carbon::createFromFormat('H:i:s', $booking->end_time);
                                        $duration = $startTime->diffInHours($endTime);
                                        $isStart = $booking->start_time == $slot . ':00';
                                        $isEnd = $booking->end_time == $slot . ':00';
                                    @endphp
                                    <button class="my-booking-btn w-full py-3 px-4 font-semibold rounded-xl border-2 border-blue-300 bg-blue-100 text-blue-700 hover:bg-blue-200 transition-all transform hover:scale-105 shadow-sm"
                                            data-booking-id="{{ $booking->id }}">
                                        <div class="flex flex-col items-center justify-center gap-1">
                                            <div class="flex items-center gap-2">
                                                <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                                </svg>
                                                @if($isStart)
                                                    My Booking
                                                @else
                                                    {{ $duration }}h Booking
                                                @endif
                                            </div>
                                            @if($isStart)
                                                <div class="text-xs text-blue-600">
                                                    {{ $startTime->format('g:i A') }} - {{ $endTime->format('g:i A') }}
                                                </div>
                                            @endif
                                        </div>
                                    </button>
                                @elseif($booking)
                                    @php
                                        $startTime = \Carbon\Carbon::createFromFormat('H:i:s', $booking->start_time);
                                        $endTime = \Carbon\Carbon::createFromFormat('H:i:s', $booking->end_time);
                                        $duration = $startTime->diffInHours($endTime);
                                        $isStart = $booking->start_time == $slot . ':00';
                                        $isEnd = $booking->end_time == $slot . ':00';
                                    @endphp
                                    <div class="other-booking-btn w-full py-3 px-4 font-semibold rounded-xl border-2 border-red-300 bg-red-100 text-red-700 cursor-not-allowed shadow-sm">
                                        <div class="flex flex-col items-center justify-center gap-1">
                                            <div class="flex items-center gap-2">
                                                <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L3.732 16.5c-.77.833.192 2.5 1.732 2.5z" />
                                                </svg>
                                                @if($isStart)
                                                    Booked
                                                @else
                                                    {{ $duration }}h Booked
                                                @endif
                                            </div>
                                            @if($isStart)
                                                <div class="text-xs text-red-600">
                                                    {{ $startTime->format('g:i A') }} - {{ $endTime->format('g:i A') }}
                                                </div>
                                            @endif
                                        </div>
                                    </div>
                                @else
                                    <button class="select-slot-btn w-full py-3 px-4 font-semibold rounded-xl border-2 border-green-200 bg-green-50 text-green-800 hover:bg-green-100 hover:border-green-300 transition-all transform hover:scale-105 shadow-sm" 
                                            data-court="{{ $court->id }}" data-time="{{ $slot }}"
                                            title="Select {{ $court->name }} at {{ \Carbon\Carbon::createFromFormat('H:i', $slot)->format('g:i A') }}"
                                            aria-label="Select {{ $court->name }} at {{ \Carbon\Carbon::createFromFormat('H:i', $slot)->format('g:i A') }}">
                                        <div class="flex items-center justify-center gap-2">
                                            <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                                            </svg>
                                            Select
                                        </div>
                                    </button>
                                @endif
                            </td>
                        @endforeach
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>

    <!-- Multi-Slot Selection Panel -->
    <div id="multi-slot-panel" class="fixed bottom-0 left-0 right-0 transform translate-y-full transition-transform duration-300 z-[99999]" style="display: none;">
        <div class="max-w-6xl mx-auto px-4 py-3">
            <div class="max-w-4xl mx-auto">
                <!-- Clean rounded container like date navigation -->
                <div class="bg-white rounded-lg shadow-lg border border-gray-200 p-4">
                    <div class="flex items-center justify-between gap-4">
                        <!-- Left: Title and Selected Slots -->
                        <div class="flex items-center gap-3 flex-1 min-w-0">
                            <div class="flex items-center gap-2 flex-shrink-0">
                                <div class="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                                    <svg class="w-4 h-4 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                                    </svg>
                                </div>
                                <span class="text-sm font-semibold text-gray-800">Selected Time Slots:</span>
                            </div>
                            
                            <!-- Selected Slots Display -->
                            <div id="selected-slots" class="flex flex-wrap gap-2 flex-1 min-w-0">
                                <!-- Selected slots will be displayed here -->
                            </div>
                        </div>
                        
                        <!-- Right: Summary and Actions -->
                        <div class="flex items-center gap-3 flex-shrink-0">
                            <div class="text-sm text-gray-700 bg-gray-50 px-3 py-2 rounded-lg">
                                <span id="total-slots" class="text-blue-600 font-bold">0</span> slots • 
                                <span id="total-price" class="text-green-600 font-bold">RM 0</span>
                            </div>
                            
                            <button id="clear-selection" class="px-3 py-2 text-red-600 hover:text-red-800 font-medium border border-red-200 rounded-lg hover:bg-red-50 text-sm">
                                Clear
                            </button>
                            
                            <button id="cancel-selection" class="px-4 py-2 text-gray-600 hover:text-gray-800 font-medium border border-gray-300 rounded-lg hover:bg-gray-50 text-sm">
                                Cancel
                            </button>
                            
                            <button id="confirm-multi-booking" class="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold disabled:opacity-50 disabled:cursor-not-allowed text-sm shadow-sm" disabled>
                                Confirm Booking
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Enhanced Booking Modal -->
    <div id="booking-modal" class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 hidden transition-all duration-300">
        <div class="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full mx-4 relative border border-gray-100 animate-fade-in">
            <button id="close-modal" class="absolute top-4 right-4 text-gray-400 hover:text-gray-700 text-2xl font-bold" title="Close modal" aria-label="Close booking modal">&times;</button>
            <div id="modal-content">
                <!-- Filled by JS -->
            </div>
        </div>
    </div>

    <!-- Enhanced Booking Details Modal -->
    <div id="booking-details-modal" class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 hidden">
        <div class="bg-white rounded-3xl shadow-2xl p-8 max-w-md w-full mx-4 relative border border-gray-100">
            <button id="close-details-modal" class="absolute top-4 right-4 text-gray-400 hover:text-gray-700 text-2xl font-bold" title="Close modal" aria-label="Close details modal">&times;</button>
            <div id="details-modal-content">
                <!-- Filled by JS -->
            </div>
        </div>
    </div>

    <!-- Enhanced My Bookings Modal -->
    <div id="my-bookings-modal" class="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 hidden transition-all duration-300">
        <div class="bg-white rounded-3xl shadow-2xl p-8 max-w-4xl w-full mx-4 relative border border-gray-100 animate-fade-in">
            <button id="close-my-bookings-modal" class="absolute top-4 right-4 text-gray-400 hover:text-gray-700 text-2xl font-bold" title="Close modal" aria-label="Close my bookings modal">&times;</button>
            <h2 class="text-3xl font-bold mb-6 text-blue-700 flex items-center gap-3">
                <svg class="w-8 h-8 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-6a2 2 0 012-2h2a2 2 0 012 2v6" />
                </svg>
                My Bookings
            </h2>
            <div id="my-bookings-list">
                <!-- Filled by JS -->
            </div>
        </div>
    </div>
</div>

<script>
    // Version: 3.3 - Fixed panel hiding when cleared and added more debugging
    console.log('Booking system v3.3 loaded - Fixed panel hiding when cleared and added more debugging');
    
    // Multi-slot selection state
    let selectedSlots = new Map(); // Map of slotId -> {courtId, time, courtName}
    let isMultiSelectMode = false;
    const pricePerHour = 20;

    function setToday() {
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('date-input').value = today;
        document.getElementById('date-input').form.submit();
    }
    
    function changeDate(offset) {
        const input = document.getElementById('date-input');
        const date = new Date(input.value);
        date.setDate(date.getDate() + offset);
        input.value = date.toISOString().split('T')[0];
        input.form.submit();
    }

    // Multi-slot selection functions
    function toggleSlotSelection(courtId, time, courtName) {
        const slotId = `${courtId}-${time}`;
        console.log('toggleSlotSelection called:', { courtId, time, courtName, slotId });
        
        if (selectedSlots.has(slotId)) {
            // Remove from selection
            console.log('Removing slot from selection');
            selectedSlots.delete(slotId);
            updateSlotButton(courtId, time, false);
        } else {
            // Add to selection
            console.log('Adding slot to selection');
            selectedSlots.set(slotId, {
                court_id: courtId,
                time: time,
                courtName: courtName
            });
            updateSlotButton(courtId, time, true);
        }
        
        console.log('Current selectedSlots:', selectedSlots);
        updateMultiSlotPanel();
    }

    function updateSlotButton(courtId, time, isSelected) {
        const button = document.querySelector(`button[data-court="${courtId}"][data-time="${time}"]`);
        if (!button) return;

        if (isSelected) {
            button.className = 'select-slot-btn w-full py-3 px-4 font-semibold rounded-xl border-2 border-blue-500 bg-blue-100 text-blue-800 hover:bg-blue-200 transition-all transform hover:scale-105 shadow-sm';
            button.innerHTML = `
                <div class="flex items-center justify-center gap-2">
                    <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                    </svg>
                    Selected
                </div>
            `;
        } else {
            button.className = 'select-slot-btn w-full py-3 px-4 font-semibold rounded-xl border-2 border-green-200 bg-green-50 text-green-800 hover:bg-green-100 hover:border-green-300 transition-all transform hover:scale-105 shadow-sm';
            button.innerHTML = `
                <div class="flex items-center justify-center gap-2">
                    <svg class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4" />
                    </svg>
                    Select
                </div>
            `;
        }
    }

    function updateMultiSlotPanel() {
        const panel = document.getElementById('multi-slot-panel');
        const selectedSlotsContainer = document.getElementById('selected-slots');
        const totalSlots = document.getElementById('total-slots');
        const totalPrice = document.getElementById('total-price');
        const confirmButton = document.getElementById('confirm-multi-booking');

        console.log('updateMultiSlotPanel called, selectedSlots.size:', selectedSlots.size);
        console.log('Panel element found:', !!panel);

        if (selectedSlots.size > 0) {
            // Show panel
            console.log('Showing panel...');
            panel.classList.remove('translate-y-full');
            panel.style.display = 'block';
            isMultiSelectMode = true;
            
            // Update selected slots display
            selectedSlotsContainer.innerHTML = '';
            selectedSlots.forEach((slot, slotId) => {
                const slotElement = document.createElement('div');
                slotElement.className = 'flex items-center gap-2 bg-blue-50 text-blue-800 px-3 py-2 rounded-lg text-sm font-medium border border-blue-200 whitespace-nowrap shadow-sm';
                slotElement.innerHTML = `
                    <div class="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <span class="font-semibold">${formatTime(slot.time)}</span>
                    <button onclick="removeSlot('${slotId}')" class="text-blue-600 hover:text-blue-800 hover:bg-blue-200 rounded-full p-1 transition-colors" title="Remove this slot">
                        <svg class="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                `;
                selectedSlotsContainer.appendChild(slotElement);
            });
            
            // Update totals
            totalSlots.textContent = selectedSlots.size;
            totalPrice.textContent = `RM ${selectedSlots.size * pricePerHour}`;
            confirmButton.disabled = false;
        } else {
            // Hide panel
            console.log('Hiding panel...');
            panel.classList.add('translate-y-full');
            panel.style.display = 'none';
            isMultiSelectMode = false;
            confirmButton.disabled = true;
        }
    }

    function removeSlot(slotId) {
        console.log('removeSlot called with slotId:', slotId);
        const slot = selectedSlots.get(slotId);
        if (slot) {
            console.log('Removing slot:', slot);
            updateSlotButton(slot.courtId, slot.time, false);
            selectedSlots.delete(slotId);
            updateMultiSlotPanel();
            console.log('Slot removed, remaining slots:', selectedSlots.size);
        } else {
            console.log('Slot not found:', slotId);
        }
    }

    function clearAllSelections() {
        console.log('clearAllSelections called, selectedSlots.size:', selectedSlots.size);
        selectedSlots.forEach((slot, slotId) => {
            console.log('Clearing slot:', slotId, slot);
            updateSlotButton(slot.courtId, slot.time, false);
        });
        selectedSlots.clear();
        console.log('selectedSlots cleared, new size:', selectedSlots.size);
        updateMultiSlotPanel();
        console.log('All selections cleared and panel updated');
    }

    function formatTime(time) {
        const [hours, minutes] = time.split(':');
        const hour = parseInt(hours);
        const ampm = hour >= 12 ? 'PM' : 'AM';
        const displayHour = hour % 12 || 12;
        return `${displayHour}:${minutes} ${ampm}`;
    }

    function confirmMultiBooking() {
        if (selectedSlots.size === 0) return;

        const date = document.getElementById('date-input').value;
        const slots = Array.from(selectedSlots.values());
        
        // Create booking data
        const bookingData = {
            date: date,
            slots: slots,
            total_price: slots.length * pricePerHour
        };

        // Show confirmation modal
        showMultiBookingConfirmation(bookingData);
    }

    function showMultiBookingConfirmation(bookingData) {
        const modal = document.getElementById('booking-modal');
        const modalContent = document.getElementById('modal-content');
        
        const slotsHtml = bookingData.slots.map(slot => 
            `<div class="flex justify-between items-center py-2 border-b border-gray-100 last:border-b-0">
                <span class="font-medium">${slot.courtName}</span>
                <span class="text-gray-600">${formatTime(slot.time)}</span>
            </div>`
        ).join('');

        modalContent.innerHTML = `
            <div class="text-center">
                <div class="w-20 h-20 bg-gradient-to-br from-blue-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                    <svg class="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                </div>
                <h2 class="text-2xl font-bold mb-4 text-gray-800">Confirm Multi-Slot Booking</h2>
                <div class="bg-gray-50 rounded-xl p-6 mb-6">
                    <div class="text-left mb-4">
                        <span class="text-gray-600 text-sm">Date</span>
                        <p class="font-semibold text-gray-800">${bookingData.date}</p>
                    </div>
                    <div class="text-left mb-4">
                        <span class="text-gray-600 text-sm">Selected Slots</span>
                        <div class="mt-2">
                            ${slotsHtml}
                        </div>
                    </div>
                    <div class="mt-4 pt-4 border-t border-gray-200">
                        <div class="flex justify-between items-center">
                            <span class="text-lg font-semibold text-gray-800">Total Price</span>
                            <span class="text-2xl font-bold text-blue-600">RM ${bookingData.total_price}</span>
                        </div>
                    </div>
                </div>
                <div class="flex gap-3">
                    <button id="cancel-multi-booking" class="flex-1 px-4 py-3 text-gray-600 hover:text-gray-800 font-medium">
                        Cancel
                    </button>
                    <button id="submit-multi-booking" class="flex-1 px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold">
                        Confirm & Pay
                    </button>
                </div>
            </div>
        `;
        
        modal.classList.remove('hidden');
        
        // Add event listeners
        document.getElementById('cancel-multi-booking').onclick = () => {
            modal.classList.add('hidden');
        };
        
        document.getElementById('submit-multi-booking').onclick = () => {
            submitMultiBooking(bookingData);
        };
    }

    function submitMultiBooking(bookingData) {
        console.log('Submitting multi-booking with data:', bookingData);
        
        // Disable the submit button to prevent double submission
        const submitButton = document.getElementById('submit-multi-booking');
        if (submitButton) {
            submitButton.disabled = true;
            submitButton.textContent = 'Processing...';
        }
        
        // Create form data
        const formData = new FormData();
        formData.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));
        formData.append('date', bookingData.date);
        formData.append('slots', JSON.stringify(bookingData.slots));
        formData.append('total_price', bookingData.total_price);
        
        console.log('Form data slots:', JSON.stringify(bookingData.slots));

        // Submit booking with cache-busting
        const url = '/bookings/multi?v=' + Date.now(); // Cache busting
        fetch(url, {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
                'Cache-Control': 'no-cache'
            },
            cache: 'no-cache'
        })
        .then(response => {
            console.log('Response status:', response.status);
            if (!response.ok) {
                throw new Error(`Server returned ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Response data:', data);
            
            // Clear selections and hide panel
            clearAllSelections();
            document.getElementById('booking-modal').classList.add('hidden');
            
            if (data.success) {
                // Show success message
                if (data.bookings_created === data.total_slots) {
                    alert('All bookings confirmed successfully! The page will refresh to show your bookings.');
                } else {
                    const errorText = data.errors && data.errors.length > 0 ? data.errors.join('\n') : 'No specific errors reported';
                    alert(`${data.bookings_created} booking(s) confirmed successfully!\n\nSome slots were unavailable:\n${errorText}\n\nThe page will refresh to show your bookings.`);
                }
                
                // Reload page to show updated bookings
                setTimeout(() => location.reload(), 500);
            } else {
                // Even if success is false, some bookings might have been created
                if (data.bookings_created > 0) {
                    const errorText = data.errors && data.errors.length > 0 ? data.errors.join('\n') : 'No specific errors reported';
                    alert(`${data.bookings_created} booking(s) confirmed successfully!\n\nSome slots were unavailable:\n${errorText}\n\nThe page will refresh to show your bookings.`);
                    setTimeout(() => location.reload(), 500);
                } else {
                    // No bookings were created at all
                    let errorMsg = data.message || 'Failed to create booking';
                    if (data.errors && data.errors.length > 0) {
                        errorMsg += '\n\nUnavailable slots:\n' + data.errors.join('\n');
                    }
                    alert('Error: ' + errorMsg);
                    // Re-enable the button
                    if (submitButton) {
                        submitButton.disabled = false;
                        submitButton.textContent = 'Confirm & Pay';
                    }
                }
            }
        })
        .catch(error => {
            console.error('Network or parsing error:', error);
            alert('Network error creating booking. Please check your connection and try again.');
            // Clear selections and hide panel
            clearAllSelections();
            document.getElementById('booking-modal').classList.add('hidden');
            // Re-enable the button
            if (submitButton) {
                submitButton.disabled = false;
                submitButton.textContent = 'Confirm & Pay';
            }
        });
    }

    // DISABLED: Enhanced Live Grid Coloring (was causing incorrect display)
    // const userId = {{ auth()->id() }};
    // const courts = @json($courts->pluck('id'));
    // const slots = @json($timeSlots);
    
    // function updateGrid() {
    //     // This function was overriding the correct server-side rendering
    //     // and causing "My Booking" slots to show as "Book Now"
    // }

    function showBookingModal(courtId, slot) {
        console.log('showBookingModal called with:', { courtId, slot });
        const courtName = document.querySelector(`th[data-court-id='${courtId}']`)?.innerText || '';
        const date = document.getElementById('date-input').value;
        const startTime = slot;
        // Calculate end time correctly (8am -> 9am, not 9am -> 10am)
        const startHour = parseInt(startTime.split(':')[0]);
        const endHour = startHour + 1;
        const endTime = endHour.toString().padStart(2, '0') + ':00';
        const price = 20;
        
        console.log('Modal data:', { courtName, date, startTime, endTime, price });
        
        const modal = document.getElementById('booking-modal');
        const modalContent = document.getElementById('modal-content');
        
        modalContent.innerHTML = `
            <div class="text-center">
                <div class="w-20 h-20 bg-gradient-to-br from-blue-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-6">
                    <svg class="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                </div>
                <h2 class="text-2xl font-bold mb-4 text-gray-800">Confirm Your Booking</h2>
                <div class="bg-gray-50 rounded-xl p-6 mb-6">
                    <div class="grid grid-cols-2 gap-4 text-left">
                        <div>
                            <span class="text-gray-600 text-sm">Court</span>
                            <p class="font-semibold text-gray-800">${courtName}</p>
                        </div>
                        <div>
                            <span class="text-gray-600 text-sm">Date</span>
                            <p class="font-semibold text-gray-800">${date}</p>
                        </div>
                        <div>
                            <span class="text-gray-600 text-sm">Time</span>
                            <p class="font-semibold text-gray-800">${startTime} - ${endTime}</p>
                        </div>
                        <div>
                            <span class="text-gray-600 text-sm">Duration</span>
                            <p class="font-semibold text-gray-800">1 hour</p>
                        </div>
                    </div>
                    <div class="mt-4 pt-4 border-t border-gray-200">
                        <div class="flex justify-between items-center">
                            <span class="text-lg font-semibold text-gray-800">Total Price</span>
                            <span class="text-2xl font-bold text-blue-600">RM ${price}</span>
                        </div>
                    </div>
                </div>
                <button id="single-booking-submit" type="button" class="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-4 rounded-xl font-bold hover:from-blue-700 hover:to-blue-800 transition-all transform hover:scale-105 text-lg shadow-lg">
                    Confirm Booking
                </button>
            </div>
        `;
        
        modal.classList.remove('hidden');
        setTimeout(() => modal.classList.add('opacity-100'), 10);
        
        // Add event listener for the submit button
        document.getElementById('single-booking-submit').onclick = function() {
            submitSingleBooking(courtId, date, startTime, endTime);
        };
    }
    
    function submitSingleBooking(courtId, date, startTime, endTime) {
        const submitButton = document.getElementById('single-booking-submit');
        if (submitButton) {
            submitButton.disabled = true;
            submitButton.textContent = 'Processing...';
        }
        
        const formData = new FormData();
        formData.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));
        formData.append('court_id', courtId);
        formData.append('date', date);
        formData.append('start_time', startTime);
        formData.append('end_time', endTime);
        
        // Submit with cache-busting
        const url = '{{ route("bookings.store") }}?v=' + Date.now();
        fetch(url, {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest',
                'Accept': 'application/json',
                'Cache-Control': 'no-cache'
            },
            cache: 'no-cache'
        })
        .then(response => {
            console.log('Response status:', response.status);
            if (!response.ok) {
                return response.json().then(err => {
                    throw err;
                });
            }
            return response.json();
        })
        .then(data => {
            console.log('Response data:', data);
            
            // Hide modal
            document.getElementById('booking-modal').classList.add('hidden');
            
            if (data.success) {
                alert('Booking created successfully! The page will refresh to show your booking.');
                setTimeout(() => location.reload(), 500);
            } else {
                alert('Error: ' + (data.message || 'Failed to create booking'));
                if (submitButton) {
                    submitButton.disabled = false;
                    submitButton.textContent = 'Confirm Booking';
                }
            }
        })
        .catch(error => {
            console.error('Booking error:', error);
            document.getElementById('booking-modal').classList.add('hidden');
            
            let errorMessage = 'Failed to create booking. ';
            if (error.message) {
                errorMessage += error.message;
            } else if (error.errors) {
                errorMessage += Object.values(error.errors).flat().join(', ');
            } else {
                errorMessage += 'Please check your connection and try again.';
            }
            
            alert(errorMessage);
            
            if (submitButton) {
                submitButton.disabled = false;
                submitButton.textContent = 'Confirm Booking';
            }
        });
    }

    // Event Listeners
    // DISABLED: These were causing the grid to override correct display
    // document.getElementById('date-input').addEventListener('change', updateGrid);
    // window.addEventListener('DOMContentLoaded', updateGrid);
    
    const closeModalBtn = document.getElementById('close-modal');
    if (closeModalBtn) {
        closeModalBtn.onclick = function() {
            document.getElementById('booking-modal').classList.add('hidden');
        };
    }
    
    const closeDetailsModalBtn = document.getElementById('close-details-modal');
    if (closeDetailsModalBtn) {
        closeDetailsModalBtn.onclick = function() {
            document.getElementById('booking-details-modal').classList.add('hidden');
        };
    }
    
    const closeMyBookingsModalBtn = document.getElementById('close-my-bookings-modal');
    if (closeMyBookingsModalBtn) {
        closeMyBookingsModalBtn.onclick = function() {
            document.getElementById('my-bookings-modal').classList.add('hidden');
        };
    }

    // Enhanced My Booking Button Listeners
    function addMyBookingBtnListeners() {
        document.querySelectorAll('.my-booking-btn').forEach(btn => {
            btn.onclick = function(e) {
                e.preventDefault();
                const bookingId = this.getAttribute('data-booking-id');
                fetch(`/booking-details/${bookingId}`)
                    .then(r => r.json())
                    .then(booking => {
                        let html = `
                            <div class="text-center">
                                <div class="w-16 h-16 bg-gradient-to-br from-blue-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                                    <svg class="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                    </svg>
                                </div>
                                <h2 class="text-2xl font-bold mb-4 text-gray-800">Booking Details</h2>
                                <div class="bg-gray-50 rounded-xl p-6 mb-6">
                                    <div class="space-y-3 text-left">
                                        <div class="flex justify-between">
                                            <span class="text-gray-600">Court:</span>
                                            <span class="font-semibold">${booking.court.name}</span>
                                        </div>
                                        <div class="flex justify-between">
                                            <span class="text-gray-600">Date:</span>
                                            <span class="font-semibold">${booking.date}</span>
                                        </div>
                                        <div class="flex justify-between">
                                            <span class="text-gray-600">Time:</span>
                                            <span class="font-semibold">${booking.start_time} - ${booking.end_time}</span>
                                        </div>
                                        <div class="flex justify-between">
                                            <span class="text-gray-600">Total Price:</span>
                                            <span class="font-bold text-blue-600">RM ${booking.total_price}</span>
                                        </div>
                                    </div>
                                </div>
                        `;
                        
                        if (booking.payment && booking.payment.status === 'pending') {
                            html += `
                                <a href="/payments/${booking.payment.id}/pay" class="block w-full bg-gradient-to-r from-green-600 to-green-700 text-white py-3 rounded-xl font-bold text-center mb-3 hover:from-green-700 hover:to-green-800 transition-all transform hover:scale-105">
                                    Proceed to Payment
                                </a>
                            `;
                        }
                        
                        html += `
                                <form method="POST" action="/bookings/${booking.id}" class="mt-3">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="w-full bg-gradient-to-r from-red-600 to-red-700 text-white py-3 rounded-xl font-bold hover:from-red-700 hover:to-red-800 transition-all transform hover:scale-105">
                                        Cancel Booking
                                    </button>
                                </form>
                            </div>
                        `;
                        
                        document.getElementById('details-modal-content').innerHTML = html;
                        document.getElementById('booking-details-modal').classList.remove('hidden');
                    });
            };
        });
    }

    // Enhanced Slot Selection Listeners
    function addSlotSelectionListeners() {
        console.log('Setting up slot selection listeners...');
        const buttons = document.querySelectorAll('.select-slot-btn');
        console.log('Found', buttons.length, 'Select buttons');
        
        buttons.forEach((btn, index) => {
            console.log('Setting up listener for button', index + 1, 'with data:', {
                court: btn.getAttribute('data-court'),
                time: btn.getAttribute('data-time')
            });
            
            btn.onclick = function(e) {
                e.preventDefault();
                console.log('Select button clicked!');
                const courtId = this.getAttribute('data-court');
                const slot = this.getAttribute('data-time');
                const courtName = document.querySelector(`th[data-court-id='${courtId}']`)?.innerText || `Court ${courtId}`;
                console.log('Court ID:', courtId, 'Slot:', slot, 'Court Name:', courtName);
                toggleSlotSelection(courtId, slot, courtName);
            };
        });
    }

    // Enhanced My Bookings Modal
    const openMyBookingsBtn = document.getElementById('open-my-bookings');
    if (openMyBookingsBtn) {
        openMyBookingsBtn.onclick = function(e) {
        e.preventDefault();
        fetch('/user-bookings')
            .then(r => r.json())
            .then(bookings => {
                let html = '';
                if (bookings.length === 0) {
                    html = `
                        <div class="text-center py-12">
                            <div class="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                                <svg class="w-12 h-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-6a2 2 0 012-2h2a2 2 0 012 2v6" />
                                </svg>
                            </div>
                            <h3 class="text-xl font-semibold text-gray-600 mb-2">No Bookings Yet</h3>
                            <p class="text-gray-500">You haven't made any bookings yet. Start by booking a court!</p>
                        </div>
                    `;
                } else {
                    html = `
                        <div class="overflow-x-auto">
                            <table class="min-w-full">
                                <thead>
                                    <tr class="bg-gray-50 border-b border-gray-200">
                                        <th class="py-3 px-4 text-left font-semibold text-gray-700">Court</th>
                                        <th class="py-3 px-4 text-left font-semibold text-gray-700">Date</th>
                                        <th class="py-3 px-4 text-left font-semibold text-gray-700">Time</th>
                                        <th class="py-3 px-4 text-left font-semibold text-gray-700">Status</th>
                                        <th class="py-3 px-4 text-left font-semibold text-gray-700">Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                    `;
                    
                    bookings.forEach(b => {
                        let status = b.payment && b.payment.status === 'pending' ? 'Pending Payment' : 'Booked';
                        let statusClass = b.payment && b.payment.status === 'pending' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800';
                        
                        html += `
                            <tr class="hover:bg-gray-50 cursor-pointer my-booking-row border-b border-gray-100" data-booking-id="${b.id}">
                                <td class="py-4 px-4 font-medium">${b.court.name}</td>
                                <td class="py-4 px-4">${b.date}</td>
                                <td class="py-4 px-4">${b.start_time} - ${b.end_time}</td>
                                <td class="py-4 px-4">
                                    <span class="inline-block px-3 py-1 rounded-full text-xs font-bold ${statusClass}">
                                        ${status}
                                    </span>
                                </td>
                                <td class="py-4 px-4">
                                    <button class="text-blue-600 hover:text-blue-800 font-medium details-btn" data-booking-id="${b.id}">
                                        View Details
                                    </button>
                                </td>
                            </tr>
                        `;
                    });
                    
                    html += `
                                </tbody>
                            </table>
                        </div>
                    `;
                }
                
                document.getElementById('my-bookings-list').innerHTML = html;
                document.getElementById('my-bookings-modal').classList.remove('hidden');
                
                // Add click listeners for details
                document.querySelectorAll('.details-btn, .my-booking-row').forEach(btn => {
                    btn.onclick = function(e) {
                        e.preventDefault();
                        const bookingId = this.getAttribute('data-booking-id');
                        fetch(`/booking-details/${bookingId}`)
                            .then(r => r.json())
                            .then(booking => {
                                let html = `
                                    <div class="text-center">
                                        <div class="w-16 h-16 bg-gradient-to-br from-blue-500 to-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                                            <svg class="w-8 h-8 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                                            </svg>
                                        </div>
                                        <h2 class="text-2xl font-bold mb-4 text-gray-800">Booking Details</h2>
                                        <div class="bg-gray-50 rounded-xl p-6 mb-6">
                                            <div class="space-y-3 text-left">
                                                <div class="flex justify-between">
                                                    <span class="text-gray-600">Court:</span>
                                                    <span class="font-semibold">${booking.court.name}</span>
                                                </div>
                                                <div class="flex justify-between">
                                                    <span class="text-gray-600">Date:</span>
                                                    <span class="font-semibold">${booking.date}</span>
                                                </div>
                                                <div class="flex justify-between">
                                                    <span class="text-gray-600">Time:</span>
                                                    <span class="font-semibold">${booking.start_time} - ${booking.end_time}</span>
                                                </div>
                                                <div class="flex justify-between">
                                                    <span class="text-gray-600">Total Price:</span>
                                                    <span class="font-bold text-blue-600">RM ${booking.total_price}</span>
                                                </div>
                                            </div>
                                        </div>
                                `;
                                
                                if (booking.payment && booking.payment.status === 'pending') {
                                    html += `
                                        <a href="/payments/${booking.payment.id}/pay" class="block w-full bg-gradient-to-r from-green-600 to-green-700 text-white py-3 rounded-xl font-bold text-center mb-3 hover:from-green-700 hover:to-green-800 transition-all transform hover:scale-105">
                                            Proceed to Payment
                                        </a>
                                    `;
                                }
                                
                                html += `
                                        <form method="POST" action="/bookings/${booking.id}" class="mt-3">
                                            @csrf @method('DELETE')
                                            <button type="submit" class="w-full bg-gradient-to-r from-red-600 to-red-700 text-white py-3 rounded-xl font-bold hover:from-red-700 hover:to-red-800 transition-all transform hover:scale-105">
                                                Cancel Booking
                                            </button>
                                        </form>
                                    </div>
                                `;
                                
                                document.getElementById('details-modal-content').innerHTML = html;
                                document.getElementById('booking-details-modal').classList.remove('hidden');
                            });
                    };
                });
            });
        };
    }

    // Multi-slot panel event listeners
    function setupMultiSlotEventListeners() {
        console.log('Setting up multi-slot event listeners...');
        const clearButton = document.getElementById('clear-selection');
        const cancelButton = document.getElementById('cancel-selection');
        const confirmButton = document.getElementById('confirm-multi-booking');
        
        console.log('Buttons found:', {
            clearButton: !!clearButton,
            cancelButton: !!cancelButton,
            confirmButton: !!confirmButton
        });
        
        if (clearButton) {
            clearButton.onclick = clearAllSelections;
            console.log('Clear button event listener set');
        }
        if (cancelButton) {
            cancelButton.onclick = clearAllSelections;
            console.log('Cancel button event listener set');
        }
        if (confirmButton) {
            confirmButton.onclick = confirmMultiBooking;
            console.log('Confirm button event listener set');
        }
    }
    
    // Setup event listeners when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', setupMultiSlotEventListeners);
    } else {
        setupMultiSlotEventListeners();
    }

    // Initial event listeners setup
    console.log('Initializing booking page...');
    addSlotSelectionListeners();
    console.log('Booking page initialization complete.');
</script>

<style>
@keyframes fade-in {
    from { opacity: 0; transform: translateY(20px) scale(0.95); }
    to { opacity: 1; transform: translateY(0) scale(1); }
}
.animate-fade-in { animation: fade-in 0.3s cubic-bezier(0.4, 0, 0.2, 1) both; }
</style>
@endsection 